public class Myclass {
    public static void main(String[] args) {
     String primeiroNome = "Wosley";
     String segundoNome = "Arruda";

//      System.out.println(primeiroNome);
//     System.out.println(segundoNome);
      String nomeCompleto = nomeCompleto(primeiroNome, segundoNome);
      System.out.println(nomeCompleto);
    }
    public static String nomeCompleto (String primeiroNome , String segundoNome){
        return primeiroNome.concat(" ").concat(segundoNome);
    }
}